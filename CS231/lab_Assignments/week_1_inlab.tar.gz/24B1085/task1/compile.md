Compile using:

`iverilog -o testbench testbench.v module.v`

Run using:

`vvp testbench`

See gtkwave output using:

`gtkwave wave.vcd`