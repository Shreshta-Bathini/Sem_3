Compile using:

`iverilog -o testbench testbench.v module.v`

See gtkwave output using:

`gtkwave wave.vcd`