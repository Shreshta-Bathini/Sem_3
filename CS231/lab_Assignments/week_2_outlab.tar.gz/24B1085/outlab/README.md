# Goal
Cycle through the following sequence of colors:
- White (111)
- Blue (010)
- Cyan (011)
- Red (100)
- Purple (110)
- Yellow (101)
- Green (001)
- Black (000)
## Procedure
### Step 1
Make a standard 3 bit counter. You cannot use any arithmetic operations or conditional statements

Do this using a digital logic circuit

### Step 2
Make a digital logic circuit that maps the states