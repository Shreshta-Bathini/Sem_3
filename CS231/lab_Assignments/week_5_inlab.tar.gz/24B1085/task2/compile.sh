nasm -f elf64 conditional-statements.asm -o conditional-statements.o
ld conditional-statements.o -o conditional-statements