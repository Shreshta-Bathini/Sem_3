# Week 2
The goal of this week is to learn constructs such as loops and functions as well as function recursion in asm
## Task 1
### Loops
- The goal of this lab is going to be to find out the nth fibonacci number (assume 0th fibonacci number is 0, 1st is 1 and ith number is (i-1)th number + (i-2)th number), after taking n as input from user
- You have been given C code, you have to translate it into asm
## Task 2
### Tower of Hanoi
- Classic towers of hanoi problem
- See youtube video: https://www.youtube.com/watch?v=rf6uf3jNjbo&ab_channel=Reducible
- Note video transfers disks from `A` to `C`, we have to transfer from `A` to `B`